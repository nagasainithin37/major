import styled from "styled-components";
const ModalContainer = styled.div`


`

export default ModalContainer;