import styled from "styled-components";

const HomeContainer = styled.div`

.loginForm{
    padding: 20px;
    box-shadow: inset 0px 1px 4px 0px #2b58c3;

}
`

export default HomeContainer;